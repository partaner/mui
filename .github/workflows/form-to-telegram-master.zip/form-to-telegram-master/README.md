# form-to-telegram
Simple HTML form to Telegram message
